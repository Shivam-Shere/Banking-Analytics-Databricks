# Databricks notebook source
# MAGIC %md
# MAGIC # **1. Import Libraries:**

# COMMAND ----------

from pyspark.sql import types as t 
from pyspark.sql import functions as f 

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Data Load and Inspection**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True).load('/Volumes/banking_analytics/bronze_layer/raw_data/accounts.csv')
df.display()    

# COMMAND ----------

display(df.limit(10)) 

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(f'Rows: {df.count()}')
print(f'Column: {len(df.columns)}')

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns.)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('account_id').isNull().cast('int')).alias('null_account_id')
).display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns
]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "accounts" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.accounts_bronze')  

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.accounts_bronze;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 

# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(open_date), max(open_date)
# MAGIC from banking_analytics.bronze_layer.accounts_bronze;

# COMMAND ----------

## 1. Calculated column: "Account Open Year"

df_transform = df.withColumn(
    'acc_open_year',
    f.year(f.col('open_date'))
)
df_transform.display()

# COMMAND ----------

## 2. Calculated column: "Account Open Year-Month"

df_transform = df.withColumn(
    'acc_open_yr-mon',
    f.date_format(f.col('open_date'), 'yyyy-MM')
)
df_transform.display()    

# COMMAND ----------

## 3. Calculated column: "Employee Role Group"

df_transform = df.withColumn(
    "acc_age_band",
    f.when(
        f.floor(f.datediff(f.current_date(), f.col("open_date")) / 365.25) < 2,
        "New Account (0-1 Years)"
    )
    .when(
        f.floor(f.datediff(f.current_date(), f.col("open_date")) / 365.25) < 5,
        "Growing Account (2-4 Years)"
    )
    .when(
        f.floor(f.datediff(f.current_date(), f.col("open_date")) / 365.25) < 10,
        "Established Account (5-9 Years)"
    )
    .otherwise("Mature Account (10+ Years)")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(status), count(*) as cnt_status
# MAGIC from banking_analytics.bronze_layer.accounts_bronze
# MAGIC group by status
# MAGIC order by cnt_status desc;

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(account_type), count(*) as cnt_account
# MAGIC from banking_analytics.bronze_layer.accounts_bronze
# MAGIC group by account_type
# MAGIC order by cnt_account desc;   

# COMMAND ----------

## 4. Calculated column: "Account Type Group"

df_transform = df.withColumn(
    "account_type_group",
    f.when(f.col("account_type").isin("Savings", "Salary"), "Retail Deposit")
    .when(f.col("account_type").isin("Current"), "Business / Transactional")
    .when(f.col("account_type").isin("Fixed Deposit"), "Investment / Term Deposit")
    .when(f.col("account_type").isin("NRI"), "NRI Banking")

    .otherwise("Other")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(balance), max(balance)
# MAGIC from banking_analytics.bronze_layer.accounts_bronze;

# COMMAND ----------

## 5. Calculated column: "Balance Band"

df_transform = df.withColumn(
    "balance_band",
    f.when(f.col("balance") < 1000, "Very Low")
     .when(f.col("balance") < 50000, "Low")
     .when(f.col("balance") < 100000, "Moderate")
     .when(f.col("balance") < 250000, "High")
     .when(f.col("balance") < 500000, "Very High")

     .otherwise("Premium Balanace")
)
df_transform.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **5.  Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    'acc_open_year',
    f.year(f.col('open_date'))

).withColumn(
    'acc_open_yr-mon',
    f.date_format(f.col('open_date'), 'yyyy-MM')

).withColumn(
    "acc_age_band",
    f.when(
        f.floor(f.datediff(f.current_date(), f.col("open_date")) / 365.25) < 2,
        "New Account (0-1 Years)"
    )
    .when(
        f.floor(f.datediff(f.current_date(), f.col("open_date")) / 365.25) < 5,
        "Growing Account (2-4 Years)"
    )
    .when(
        f.floor(f.datediff(f.current_date(), f.col("open_date")) / 365.25) < 10,
        "Established Account (5-9 Years)"
    )
    .otherwise("Mature Account (10+ Years)")

).withColumn(
    "account_type_group",
    f.when(f.col("account_type").isin("Savings", "Salary"), "Retail Deposit")
    .when(f.col("account_type").isin("Current"), "Business / Transactional")
    .when(f.col("account_type").isin("Fixed Deposit"), "Investment / Term Deposit")
    .when(f.col("account_type").isin("NRI"), "NRI Banking")

    .otherwise("Other")

).withColumn(
    "balance_band",
    f.when(f.col("balance") < 1000, "Very Low")
     .when(f.col("balance") < 50000, "Low")
     .when(f.col("balance") < 100000, "Moderate")
     .when(f.col("balance") < 250000, "High")
     .when(f.col("balance") < 500000, "Very High")

     .otherwise("Premium Balanace")
)


# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.account_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists using SQL
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.account_silver;

# COMMAND ----------

## Remove unnecessary columns- "acc_status_group"

df = spark.read.table('banking_analytics.silver_layer.account_silver')
df = df.drop("acc_status_group")

df.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("banking_analytics.silver_layer.account_silver")

df.display()
df.printSchema()    

# COMMAND ----------

## Drop table if it's incorrect
#spark.sql('drop table if exists banking_analytics.silver_layer.acccount_silver')