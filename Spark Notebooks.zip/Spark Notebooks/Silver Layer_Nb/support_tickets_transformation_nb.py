# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t
from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
     .option('header', True). load('/Volumes/banking_analytics/bronze_layer/raw_data/support_tickets.csv')

display(df)

# COMMAND ----------

display(df.limit(10)) 

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('ticket_id').isNull().cast('int')).alias('null_ticket_id')
).display(df)

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns

]).display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "branches" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.support_ticket_bronze')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.support_ticket_bronze;

# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(date_opened), max(date_opened), min(date_resolved), max(date_resolved)
# MAGIC from banking_analytics.bronze_layer.support_ticket_bronze; 

# COMMAND ----------

## 1. Calculated column: "issue date"

df_transform = df.withColumn(
    "ticket_year",
    f.year(f.col("date_opened"))

).withColumn(
    "ticket_month",
    f.month(f.col("date_opened"))

).withColumn("ticket_year_month",
    f.date_format(f.col("date_opened"), "yyyy-MM")

).withColumn(
    "ticket_day",
    f.dayofmonth(f.col("date_opened"))

).withColumn(
    "ticket_quarter",
    f.concat(
        f.lit("Q"),
        f.quarter(f.col("date_opened"))
    )
)

display(df_transform)

# COMMAND ----------

## 2. Calculated column: "resolve date"

df_transform = df.withColumn(
    "resolve_year",
    f.year(f.col("date_resolved"))

).withColumn(
    "resolve_month",
    f.month(f.col("date_resolved"))

).withColumn("resolve_year_month",
    f.date_format(f.col("date_resolved"), "yyyy-MM")

).withColumn(
    "resolve_day",
    f.dayofmonth(f.col("date_resolved"))
)

display(df_transform)

# COMMAND ----------

## 3. Calculated column: "resolved flag"

df_transform = df.withColumn(
    "is_resolved",
    f.when(
        f.lower(f.col("status")).isin("resolved"), 1)
     .otherwise(0)
)
display(df_transform)

# COMMAND ----------

# MAGIC %sql
# MAGIC select status, count(*) as cnt_status
# MAGIC from banking_analytics.bronze_layer.support_ticket_bronze
# MAGIC group by status
# MAGIC order by cnt_status desc;

# COMMAND ----------

# MAGIC %sql
# MAGIC select satisfaction_score, count(*) as cnt_satisfaction_score
# MAGIC from banking_analytics.bronze_layer.support_ticket_bronze
# MAGIC group by satisfaction_score
# MAGIC order by cnt_satisfaction_score desc;

# COMMAND ----------

## 4. Calculated column: "satisfaction category"

df_transform = df.withColumn(
    "satisfaction_category",
    f.when(f.col("satisfaction_score") == 5, "Excellent")
     .when(f.col("satisfaction_score") == 4, "Good")
     .when(f.col("satisfaction_score") == 3, "Neutral")
     .when(f.col("satisfaction_score").isin(1, 2), "Poor")

     .otherwise("Not Rated")
)
display(df_transform)

# COMMAND ----------

## 5. Calculated column: "resolution days and time band"

df_transform = df.withColumn(
    "resolution_days",
    f.when(
        (f.col("status") == "Resolved") &
        (f.col("date_resolved").isNotNull()),
        f.datediff(
            f.to_date(f.col("date_resolved")),
            f.to_date(f.col("date_opened"))
        )
    )

).withColumn(
    "resolution_time_band",
    f.when((f.col("status") == "Resolved") & (f.col("resolution_days") <= 1), "Same / Next Day")
    .when((f.col("status") == "Resolved") & (f.col("resolution_days") <= 3), "2-3 Days")
    .when((f.col("status") == "Resolved") & (f.col("resolution_days") <= 7), "4-7 Days")
    .when((f.col("status") == "Resolved") & (f.col("resolution_days") <= 14), "8-14 Days")
    .when((f.col("status") == "Resolved") & (f.col("resolution_days") > 14), "15+ Days")

    .otherwise("Not Resolved")
)

display(df_transform)

# COMMAND ----------

## 6. Calculated column: "ticket age days and age band"

df_transform = df.withColumn(
    "ticket_age_days",
    f.datediff(
        f.coalesce(f.to_date(f.col("date_resolved")), f.current_date()),
        f.to_date(f.col("date_opened"))
    )

).withColumn(
    "ticket_age_band",
    f.when(f.col("ticket_age_days") <= 2, "0-2 Days")
     .when(f.col("ticket_age_days") <= 7, "3-7 Days")
     .when(f.col("ticket_age_days") <= 14, "8-14 Days")
     .when(f.col("ticket_age_days") <= 30, "15-30 Days")

     .otherwise("30+ Days")
)
display(df_transform)

# COMMAND ----------

# MAGIC %sql
# MAGIC select issue_type, count(*) as cnt_issues
# MAGIC from banking_analytics.bronze_layer.support_ticket_bronze
# MAGIC group by issue_type
# MAGIC order by cnt_issues desc;

# COMMAND ----------

## 7. Calculated column: "issue type group"

df_transform = df.withColumn(
    "issue_type_group",
    
    f.when(f.col("issue_type").isin("Card Blocked", "Fraud Report", "Wrong Debit"), "Card & Fraud Related")

     .when(f.col("issue_type").isin("Net Banking Issue", "App Login Issue"),"Digital Banking")

     .when(f.col("issue_type").isin("Cheque Bounce", "Account Statement"),"Account & Payment")
     
     .when(f.col("issue_type").isin("Loan Query", "Interest Query"), "Loan & Interest")
     
     .when(f.col("issue_type") == "KYC Update", "KYC & Compliance")

     .otherwise("Other")
)
display(df_transform)

# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    "ticket_year",
    f.year(f.col("date_opened"))

).withColumn(
    "ticket_month",
    f.month(f.col("date_opened"))

).withColumn("ticket_year_month",
    f.date_format(f.col("date_opened"), "yyyy-MM")

).withColumn(
    "ticket_day",
    f.dayofmonth(f.col("date_opened"))

).withColumn(
    "ticket_quarter",
    f.concat(
        f.lit("Q"),
        f.quarter(f.col("date_opened"))
    )
).withColumn(
    "resolve_year",
    f.year(f.col("date_resolved"))

).withColumn(
    "resolve_month",
    f.month(f.col("date_resolved"))

).withColumn("resolve_year_month",
    f.date_format(f.col("date_resolved"), "yyyy-MM")

).withColumn(
    "resolve_day",
    f.dayofmonth(f.col("date_resolved"))

).withColumn(
    "is_resolved",
    f.when(
        f.lower(f.col("status")).isin("resolved"), 1)
     .otherwise(0)

).withColumn(
    "satisfaction_category",
    f.when(f.col("satisfaction_score") == 5, "Excellent")
     .when(f.col("satisfaction_score") == 4, "Good")
     .when(f.col("satisfaction_score") == 3, "Neutral")
     .when(f.col("satisfaction_score").isin(1, 2), "Poor")

     .otherwise("Not Rated")

).withColumn(
    "resolution_days",
    f.when(
        (f.col("status") == "Resolved") &
        (f.col("date_resolved").isNotNull()),
        f.datediff(
            f.to_date(f.col("date_resolved")),
            f.to_date(f.col("date_opened"))
        )
    )

).withColumn(
    "resolution_time_band",
    f.when((f.col("status") == "Resolved") & (f.col("resolution_days") <= 1), "Same / Next Day")
    .when((f.col("status") == "Resolved") & (f.col("resolution_days") <= 3), "2-3 Days")
    .when((f.col("status") == "Resolved") & (f.col("resolution_days") <= 7), "4-7 Days")
    .when((f.col("status") == "Resolved") & (f.col("resolution_days") <= 14), "8-14 Days")
    .when((f.col("status") == "Resolved") & (f.col("resolution_days") > 14), "15+ Days")

    .otherwise("Not Resolved")

).withColumn(
    "ticket_age_days",
    f.datediff(
        f.coalesce(f.to_date(f.col("date_resolved")), f.current_date()),
        f.to_date(f.col("date_opened"))
    )

).withColumn(
    "ticket_age_band",
    f.when(f.col("ticket_age_days") <= 2, "0-2 Days")
     .when(f.col("ticket_age_days") <= 7, "3-7 Days")
     .when(f.col("ticket_age_days") <= 14, "8-14 Days")
     .when(f.col("ticket_age_days") <= 30, "15-30 Days")

     .otherwise("30+ Days")

).withColumn(
    "issue_type_group",
    
    f.when(f.col("issue_type").isin("Card Blocked", "Fraud Report", "Wrong Debit"), "Card & Fraud Related")

     .when(f.col("issue_type").isin("Net Banking Issue", "App Login Issue"),"Digital Banking")

     .when(f.col("issue_type").isin("Cheque Bounce", "Account Statement"),"Account & Payment")
     
     .when(f.col("issue_type").isin("Loan Query", "Interest Query"), "Loan & Interest")
     
     .when(f.col("issue_type") == "KYC Update", "KYC & Compliance")

     .otherwise("Other")
)

display(df_transform)
df_transform.printSchema()


# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.ticket_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists using SQL
# MAGIC select * 
# MAGIC from banking_analytics.silver_layer.ticket_silver
# MAGIC limit 10;