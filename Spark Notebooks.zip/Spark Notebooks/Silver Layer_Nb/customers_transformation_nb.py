# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t
from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True).load('/Volumes/banking_analytics/bronze_layer/raw_data/customers.csv')

df.display()    

# COMMAND ----------

display(df.limit(10))  

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(df.count())
print(len(df.columns))

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('customer_id').isNull().cast('int')).alias('null_customer_id')
)
df.display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns
])
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "customers" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.customer_bronze')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.customer_bronze;

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct city, state
# MAGIC from banking_analytics.bronze_layer.customer_bronze;

# COMMAND ----------

## 1. Calculated column: "Full Location"

df_transform = df.withColumn(
    'customer_location',
    f.concat_ws(
        ', ',
        f.col('city'),
        f.col('state')
    )
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(state)
# MAGIC from banking_analytics.bronze_layer.customer_bronze;

# COMMAND ----------

## 2. Calculated column: "Region"

df_transform =  df.withColumn(
    'customer_region',

    f.when(f.col('state').isin('Maharashtra', 'Gujarat'), 'West')
    .when(f.col('state').isin('West Bengal'), 'East')
    .when(f.col('state').isin('Punjab', 'Uttar Pradesh', 'Rajasthan', 'Delhi'), 'North')
    .when(f.col('state').isin('Madhya Pradesh', 'Karnataka', 'Kerala', 'Tamil Nadu', 'Telangana' ), 'South')

    .otherwise('Other')

)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(join_date) as min_date,
# MAGIC max(join_date) as max_date
# MAGIC from banking_analytics.bronze_layer.customer_bronze;

# COMMAND ----------

## 3. Calculated column: "Customer Join Year"

df_transform = df.withColumn(
    'customer_join_year',
    f.year(f.col('join_date'))
)
df_transform.display()

# COMMAND ----------

## 4. Calculated column: "Customer Join Year-Month"

df_transform = df.withColumn(
    'join_year_month',
    f.date_format(f.col('join_date'), 'yyyy-MM')

)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(date_of_birth)
# MAGIC from banking_analytics.bronze_layer.customer_bronze;

# COMMAND ----------

## 5. Calculated column: "Customer Age Years"

df_transform = df.withColumn(
    'customer_age',
    f.floor(f.datediff(f.current_date(), f.col('date_of_birth')) / 365.25).cast('int')
)
df_transform.display()

# COMMAND ----------

## 6. Calculated column: "Customer Tenure Years"

df_transform = df.withColumn(
    "customer_tenure_years",
    f.floor(
        f.datediff(f.current_date(), f.col("join_date")) / 365.25
    ).cast("int")
)
df_transform.display()

# COMMAND ----------

## 7. Calculated column: "Customer Credit Risk Category"

df_transform = df.withColumn(
    "credit_risk_category",
    f.when(f.col("credit_score") < 580, "High Risk")
     .when(f.col("credit_score") < 670, "Medium-High Risk")
     .when(f.col("credit_score") < 740, "Medium Risk")
     .when(f.col("credit_score") < 800, "Low Risk")
     .otherwise("Very Low Risk")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(credit_score), max(credit_score)
# MAGIC from banking_analytics.bronze_layer.customer_bronze;
# MAGIC

# COMMAND ----------

## 8. Calculated column: "Customer Credit Score Band"

df_transform = df.withColumn(
    "credit_score_band",
    f.when(f.col("credit_score").between(300, 549), "Very Poor")
     .when(f.col("credit_score").between(550, 649), "Poor")
     .when(f.col("credit_score").between(650, 699), "Fair")
     .when(f.col("credit_score").between(700, 749), "Good")
     .when(f.col("credit_score").between(750, 799), "Very Good")
     .when(f.col("credit_score").between(800, 899), "Excellent")

     .otherwise("Unknown")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(annual_income), max(annual_income)
# MAGIC from banking_analytics.bronze_layer.customer_bronze;

# COMMAND ----------

## 9. Calculated column: "Customer Income Band"

df_transform = df.withColumn(
    "income_band",
    f.when(f.col("annual_income") < 300000, "Low Income")
     .when(f.col("annual_income") < 600000, "Lower-Middle Income")
     .when(f.col("annual_income") < 1000000, "Middle Income")
     .when(f.col("annual_income") < 2000000, "Upper Income")
     .otherwise("High Income")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(occupation)
# MAGIC from banking_analytics.bronze_layer.customer_bronze; 

# COMMAND ----------

## 10. Calculated column: "Customer occupation"

df_transform = df.withColumn(
    "customer_occupation",
    f.when(f.col("occupation") == "Student", "Student") 
     .when(f.col("occupation") == "Retired", "Retired")
     .when(f.col("occupation").isin("Salaried - Government", "Salaried - Private"), "Salaried")
     .when(f.col("occupation").isin("Self Employed", "Business Owner"), "Business & Self-Employed")
     .when(f.col("occupation") == "Freelancer", "Freelancer")

     .otherwise("Other") 
)

df_transform.display() 

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(gender)
# MAGIC from banking_analytics.bronze_layer.customer_bronze;

# COMMAND ----------

# MAGIC %sql
# MAGIC select gender, count(*) as total_count
# MAGIC from banking_analytics.bronze_layer.customer_bronze
# MAGIC where gender in ('Male', 'Female', 'Other')
# MAGIC group by gender;

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(

    "customer_occupation",
    f.when(f.col("occupation") == "Student", "Student") 
     .when(f.col("occupation") == "Retired", "Retired")
     .when(f.col("occupation").isin("Salaried - Government", "Salaried - Private"), "Salaried")
     .when(f.col("occupation").isin("Self Employed", "Business Owner"), "Business & Self-Employed")
     .when(f.col("occupation") == "Freelancer", "Freelancer")

     .otherwise("Other") 

).withColumn(
    'customer_location',
    f.concat_ws(
        ', ',
        f.col('city'),
        f.col('state')
    )

).withColumn(
    'customer_region',

    f.when(f.col('state').isin('Maharashtra', 'Gujarat'), 'West')
    .when(f.col('state').isin('West Bengal'), 'East')
    .when(f.col('state').isin('Punjab', 'Uttar Pradesh', 'Rajasthan', 'Delhi'), 'North')
    .when(f.col('state').isin('Madhya Pradesh', 'Karnataka', 'Kerala', 'Tamil Nadu', 'Telangana' ), 'South')

    .otherwise('Other')

).withColumn(
    'customer_join_year',
    f.year(f.col('join_date'))

).withColumn(
    'join_year_month',
    f.date_format(f.col('join_date'), 'yyyy-MM')

).withColumn(
    'customer_age',
    f.floor(f.datediff(f.current_date(), f.col('date_of_birth')) / 365.25).cast('int')

).withColumn(
    "age_band",   ## New calc. colmn
    f.when(f.col("customer_age") < 25, "Young")
     .when(f.col("customer_age") < 35, "Adult")
     .when(f.col("customer_age") < 50, "Middle-Aged")
     .when(f.col("customer_age") < 65, "Senior")

     .otherwise("65+")

).withColumn(
    "customer_tenure_years",
    f.floor(
        f.datediff(f.current_date(), f.col("join_date")) / 365.25
    ).cast("int")

).withColumn(
    "customer_tenure_band",   ## New calc. colmn
    f.when(f.col("customer_tenure_years") < 2, "New Customer (0-1 Years)")
     .when(f.col("customer_tenure_years") < 5, "Growing Customer (2-4 Years)")
     .when(f.col("customer_tenure_years") < 10, "Established Customer (5-9 Years)")
     .when(f.col("customer_tenure_years") < 15, "Loyal Customer (10-14 Years)")

     .otherwise("Long-Term Customer (15+ Years)")

).withColumn(
    "credit_risk_category",
    f.when(f.col("credit_score") < 580, "High Risk")
     .when(f.col("credit_score") < 670, "Medium-High Risk")
     .when(f.col("credit_score") < 740, "Medium Risk")
     .when(f.col("credit_score") < 800, "Low Risk")
     .otherwise("Very Low Risk")

).withColumn(
    "credit_score_band",
    f.when(f.col("credit_score").between(300, 549), "Very Poor")
     .when(f.col("credit_score").between(550, 649), "Poor")
     .when(f.col("credit_score").between(650, 699), "Fair")
     .when(f.col("credit_score").between(700, 749), "Good")
     .when(f.col("credit_score").between(750, 799), "Very Good")
     .when(f.col("credit_score").between(800, 899), "Excellent")

     .otherwise("Unknown")

).withColumn(
    "income_band",
    f.when(f.col("annual_income") < 300000, "Low Income")
     .when(f.col("annual_income") < 600000, "Lower-Middle Income")
     .when(f.col("annual_income") < 1000000, "Middle Income")
     .when(f.col("annual_income") < 2000000, "Upper Income")
     .otherwise("High Income")
)


# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.customer_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.customer_silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(name), count(*) as name_count
# MAGIC from banking_analytics.silver_layer.customer_silver
# MAGIC group by name
# MAGIC order by name_count desc;

# COMMAND ----------

## Drop table if it's incorrect
# spark.sql('drop table if exists banking_analytics.silver_layer.customer_silver') 