# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t
from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True). load('/Volumes/banking_analytics/bronze_layer/raw_data/transactions.csv')

df.display()    

# COMMAND ----------

display(df.limit(10))  

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(df.count())
print(len(df.columns))

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('transaction_id').isNull().cast('int')).alias('null_card_txn_id')
).display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns

]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "branches" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.transactions_bronze')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.transactions_bronze;

# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(txn_date), max(txn_date)
# MAGIC from banking_analytics.bronze_layer.transactions_bronze;

# COMMAND ----------

## 1. Calculated column: "txn year"

df_transform = df.withColumn(
    'txn_year',
    f.year(f.col('txn_date'))
)
df_transform.display()

# COMMAND ----------

## 2. Calculated column: "txn Year-Month"

df_transform =  df.withColumn(
    'txn_yr-mon',
    f.date_format(f.col('txn_date'), 'yyyy-MM')
)
df_transform.display()

# COMMAND ----------

## 3. Calculated column: "txn quarter"

df_transform = df.withColumn(
    "txn_quarter",
    f.concat(
        f.lit("Q"),
        f.quarter(f.col("txn_date"))
    )
)
df_transform.display()

# COMMAND ----------

## 4. Calculated column: "txn day name"

df_transform = df.withColumn(
    "txn_day_name",
    f.date_format(f.col("txn_date"), "EEEE")
)
df_transform.display()

# COMMAND ----------

## 5. Calculated column: "txn day type"

df_transform = df.withColumn(
    "txn_day_type",
    f.when(
        f.dayofweek(f.col("txn_date")).isin(1, 7),
        "Weekend"
    ).otherwise("Weekday")
)
df_transform.display()

# COMMAND ----------

## 6. Calculated column: "weekend flag"

df_transform = df.withColumn(
    "is_weekend_flag",
    f.when(
        f.dayofweek(f.col("txn_date")).isin(1, 7),
        1
    )
    .otherwise(0)
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(amount), max(amount)
# MAGIC from banking_analytics.bronze_layer.transactions_bronze;

# COMMAND ----------

## 7. Calculated column: "txn amount band"

df_transform = df.withColumn(
    "amount_band",
    f.when(f.col("amount") < 1000, "Low")
     .when(f.col("amount") < 10000, "Medium")
     .when(f.col("amount") < 50000, "High")
     
     .otherwise("Very High")
)
df_transform.display()

# COMMAND ----------

## 8. Calculated column: "is_high_value"

df_transform = df.withColumn(
    "is_high_value",
    f.when(f.col("amount") >= 50000, 1)
    
     .otherwise(0)
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select txn_type, count(*) as cnt_txn_type
# MAGIC from banking_analytics.bronze_layer.transactions_bronze
# MAGIC group by txn_type
# MAGIC order by cnt_txn_type desc;

# COMMAND ----------

## 9. Calculated column: "txn_type_group"

df_transform = df.withColumn(
    "txn_type_group",
    f.when(f.col("txn_type").isin("Withdrawal", "Fee Debit"), "Debit")
     .when(
        f.col("txn_type").isin("Deposit", "Interest Credit"), "Credit")
     .when(f.col("txn_type").isin("Transfer Out", "Transfer In"), "Transfer")

     .otherwise("Other")
)
display(df_transform)

# COMMAND ----------

## 10. Calculated column: "txn_direction"

df_transform = df.withColumn(
    "txn_direction",
    f.when(f.col("txn_type").isin("Withdrawal", "Transfer Out", "Fee Debit"), "Outflow")
     .when(f.col("txn_type").isin("Deposit", "Transfer In", "Interest Credit"), "Inflow")

     .otherwise("Other")
)
display(df_transform)

# COMMAND ----------

# MAGIC %sql
# MAGIC select channel, count(*) as cnt_channel
# MAGIC from banking_analytics.bronze_layer.transactions_bronze
# MAGIC group by channel
# MAGIC order by cnt_channel desc;

# COMMAND ----------

## 11. Calculated column: "channel group"

df_transform = df.withColumn(
    "channel_group",
    f.when(f.col("channel").isin("Mobile App", "UPI", "Online Banking"), "Digital")
    .when(f.col("channel") == "POS", "Merchant")
    .when(f.col("channel").isin("ATM", "Branch"), "Physical")

    .otherwise("Other")
)
display(df_transform)

# COMMAND ----------

# MAGIC %sql
# MAGIC select merchant_category, count(*) as cnt_merchant_category
# MAGIC from banking_analytics.bronze_layer.transactions_bronze
# MAGIC group by merchant_category
# MAGIC order by cnt_merchant_category desc;

# COMMAND ----------

## 12. Calculated column: "merchant category group"

df_transform = df.withColumn(
    "merchant_category_group",
    f.when(f.lower(f.col("merchant_category")).isin("groceries", "shopping"), "Retail & Grocery")
     .when(f.lower(f.col("merchant_category")).isin("dining", "entertainment"), "Lifestyle")
     .when(f.lower(f.col("merchant_category")).isin("healthcare", "insurance"), "Healthcare & Insurance")
     .when(f.lower(f.col("merchant_category")).isin("fuel", "travel"),"Travel & Transportation")
     .when(f.lower(f.col("merchant_category")).isin("utilities", "rent", "education"), "Essential Services")
     .when(f.lower(f.col("merchant_category")).isin("salary credit", "fund transfer"), "Financial Transactions")
     .when(f.lower(f.col("merchant_category")) == "atm withdrawal", "Cash Withdrawal")

    .otherwise("Other")
)
display(df_transform)

# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    'txn_year',
    f.year(f.col('txn_date'))

).withColumn(
    'txn_yr-mon',
    f.date_format(f.col('txn_date'), 'yyyy-MM')

).withColumn(
    "txn_quarter",
    f.concat(
        f.lit("Q"),
        f.quarter(f.col("txn_date"))
    )
).withColumn(
    "txn_day_name",
    f.date_format(f.col("txn_date"), "EEEE")

).withColumn(
    "txn_day_type",
    f.when(
        f.dayofweek(f.col("txn_date")).isin(1, 7),
        "Weekend"
    ).otherwise("Weekday")

).withColumn(
    "is_weekend_flag",
    f.when(
        f.dayofweek(f.col("txn_date")).isin(1, 7),
        1
    )
    .otherwise(0)

).withColumn(
    "amount_band",
    f.when(f.col("amount") < 1000, "Low")
     .when(f.col("amount") < 10000, "Medium")
     .when(f.col("amount") < 50000, "High")
     
     .otherwise("Very High")

).withColumn(
    "is_high_value",
    f.when(f.col("amount") >= 50000, 1)
    
     .otherwise(0)

).withColumn(
    "txn_type_group",
    f.when(f.col("txn_type").isin("Withdrawal", "Fee Debit"), "Debit")
     .when(
        f.col("txn_type").isin("Deposit", "Interest Credit"), "Credit")
     .when(f.col("txn_type").isin("Transfer Out", "Transfer In"), "Transfer")

     .otherwise("Other")

).withColumn(
    "txn_direction",
    f.when(f.col("txn_type").isin("Withdrawal", "Transfer Out", "Fee Debit"), "Outflow")
     .when(f.col("txn_type").isin("Deposit", "Transfer In", "Interest Credit"), "Inflow")

     .otherwise("Other")

).withColumn(
    "channel_group",
    f.when(f.col("channel").isin("Mobile App", "UPI", "Online Banking"), "Digital")
    .when(f.col("channel") == "POS", "Merchant")
    .when(f.col("channel").isin("ATM", "Branch"), "Physical")

    .otherwise("Other")

).withColumn(
    "merchant_category_group",
    f.when(f.lower(f.col("merchant_category")).isin("groceries", "shopping"), "Retail & Grocery")
     .when(f.lower(f.col("merchant_category")).isin("dining", "entertainment"), "Lifestyle")
     .when(f.lower(f.col("merchant_category")).isin("healthcare", "insurance"), "Healthcare & Insurance")
     .when(f.lower(f.col("merchant_category")).isin("fuel", "travel"),"Travel & Transportation")
     .when(f.lower(f.col("merchant_category")).isin("utilities", "rent", "education"), "Essential Services")
     .when(f.lower(f.col("merchant_category")).isin("salary credit", "fund transfer"), "Financial Transactions")
     .when(f.lower(f.col("merchant_category")) == "atm withdrawal", "Cash Withdrawal")

    .otherwise("Other")
)
display(df_transform)
df_transform.printSchema()


# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.transaction_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists using SQL
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.transaction_silver;