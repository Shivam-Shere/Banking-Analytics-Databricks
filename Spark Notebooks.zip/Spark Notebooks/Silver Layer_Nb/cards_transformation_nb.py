# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t 
from pyspark.sql import functions as f 

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True).load('/Volumes/banking_analytics/bronze_layer/raw_data/cards.csv')

df.display()  

# COMMAND ----------

display(df.limit(10))

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(df.count())
print(len(df.columns))

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('card_id').isNull().cast('int')).alias('null_payment_id')
).display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns

]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "branches" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.cards_bronze')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.cards_bronze;

# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(issue_date), max(issue_date)
# MAGIC from banking_analytics.bronze_layer.cards_bronze;

# COMMAND ----------

## 1. Calculated column: "card issue year"

df_transform = df.withColumn(
    'card_issue_year',
    f.year(f.col('issue_date'))
)
df_transform.display()

# COMMAND ----------

## 2. Calculated column: "Card Issue Year-Month"

df_transform =  df.withColumn(
    'card_issue_yr-mon',
    f.date_format(f.col('issue_date'), 'yyyy-MM')
)
df_transform.display()

# COMMAND ----------

## 3. Calculated column: "Card age years"

df_transform = df.withColumn(
    "card_age_years",
    f.floor(
        f.datediff(f.current_date(), f.col("issue_date")) / 365.25
    ).cast("int")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(expiry_date), max(expiry_date)
# MAGIC from banking_analytics.bronze_layer.cards_bronze;

# COMMAND ----------

## 4. Calculated column: "card expire year"

df_transform = df.withColumn(
    'card_expire_year',
    f.year(f.col('expiry_date'))
)
df_transform.display()

# COMMAND ----------

## 5. Calculated column: "card expire Year-Month"

df_transform =  df.withColumn(
    'card_expire_yr-mon',
    f.date_format(f.col('expiry_date'), 'yyyy-MM')
)
df_transform.display()

# COMMAND ----------

## 6. Calculated column: "card days to expire"

# Positive → days remaining  
#  0 → expires today
# Negative → already expired

df_transform = df.withColumn(
    "days_to_expiry",
    f.datediff(
        f.col("expiry_date"),
        f.current_date()
    )
)
df_transform.display()

# COMMAND ----------

## 7. Calculated column: "card is expire or not"

df_transform = df.withColumn(
    "is_expired",
    f.when(
        f.col("expiry_date") < f.current_date(),
        True
        
    ).otherwise(False)
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select credit_limit, count(*) as cnt_credit_limit
# MAGIC from banking_analytics.bronze_layer.cards_bronze
# MAGIC group by credit_limit
# MAGIC order by cnt_credit_limit desc;

# COMMAND ----------

## 8. Calculated column: "card credit limit band"

df_transform = df_transform.withColumn(
    "credit_limit_band",
    f.when(f.col("credit_limit") < 50000, "Low Limit")
     .when(f.col("credit_limit") < 200000, "Medium Limit")
     .when(f.col("credit_limit") < 350000, "High Limit")

     .otherwise("Very High Limit")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select card_type, count(*) as cnt_card
# MAGIC from banking_analytics.bronze_layer.cards_bronze
# MAGIC group by card_type
# MAGIC order by cnt_card desc;

# COMMAND ----------

# MAGIC %sql
# MAGIC select status, count(*) as cnt_status
# MAGIC from banking_analytics.bronze_layer.cards_bronze
# MAGIC group by status
# MAGIC order by cnt_status desc;

# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    'card_issue_year',
    f.year(f.col('issue_date'))

).withColumn(
    'card_issue_yr-mon',
    f.date_format(f.col('issue_date'), 'yyyy-MM')

).withColumn(
    "card_age_years",
    f.floor(
        f.datediff(f.current_date(), f.col("issue_date")) / 365.25
    ).cast("int")

).withColumn(
    "card_age_band",  ## calc colmn on "card_age_years"
    f.when(f.col("card_age_years") < 3, "1-2 Years")
     .when(f.col("card_age_years") < 5, "3-4 Years")
     .when(f.col("card_age_years") < 8, "6-7 Years")

     .otherwise("9+ Years")

).withColumn(
    'card_expire_year',
    f.year(f.col('expiry_date'))

).withColumn(
    'card_expire_yr-mon',
    f.date_format(f.col('expiry_date'), 'yyyy-MM')

).withColumn(
    "days_to_expiry",
    f.datediff(
        f.col("expiry_date"),
        f.current_date()
    )

).withColumn(
    "card_expiry_status",  ##  calc colmn on "days_to_expiry"
    f.when(f.col("days_to_expiry") < 0, "Expired")
     .when(f.col("days_to_expiry") <= 30, "Expiring Soon")
     .when(f.col("days_to_expiry") <= 90, "Expiring Within 90 Days")

     .otherwise("Valid")

).withColumn(
    "is_expired",
    f.when(
        f.col("expiry_date") < f.current_date(),
        True
        
    ).otherwise(False)

).withColumn(
    "credit_limit_band",
    f.when(f.col("credit_limit") < 50000, "Low Limit")
     .when(f.col("credit_limit") < 200000, "Medium Limit")
     .when(f.col("credit_limit") < 350000, "High Limit")

     .otherwise("Very High Limit")

)

df_transform.display()
df_transform.printSchema()


# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.cards_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists using SQL
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.cards_silver;