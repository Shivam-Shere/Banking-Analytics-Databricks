# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t 
from pyspark.sql import functions as f 

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True).load('/Volumes/banking_analytics/bronze_layer/raw_data/employees.csv')

df.display()      

# COMMAND ----------

display(df.limit(10))

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(df.count())
print(len(df.columns))

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('employee_id').isNull().cast('int')).alias('null_emp_id')
).display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns

]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "branches" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.employee_bronze')


# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.employee_bronze;

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

## Change datatype

df_transform = df.withColumn(
    "salary",
    f.col("salary").cast("float")
)

df_transform.display()
df_transform.printSchema()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(name), count(*) as cnt_name
# MAGIC from banking_analytics.bronze_layer.employee_bronze
# MAGIC group by name
# MAGIC order by cnt_name desc; 

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(hire_date), max(hire_date)
# MAGIC from banking_analytics.bronze_layer.employee_bronze; 

# COMMAND ----------

## 1. Calculated column: "Employee Hiring Year"

df_transform = df.withColumn(
    'emp_hire_year',
    f.year(f.col('hire_date'))

)
df_transform.display()

# COMMAND ----------

## 2. Calculated column: "Employee Hiring Year-Month"

df_transform =  df.withColumn(
    'emp_hire_yr-mon',
    f.date_format(f.col('hire_date'), 'yyyy-MM')
)
df_transform.display()

# COMMAND ----------

## 3. Calculated column: "Employee Tenure Years"

df_transform = df.withColumn(
    'emp_tenure_yrs',
    f.floor(
        f.datediff(f.current_date(), f.col('hire_date')) / 365.25
    ).cast('int')

)
df_transform.display() 

# COMMAND ----------

# MAGIC %sql
# MAGIC select max(salary), min(salary)
# MAGIC from banking_analytics.bronze_layer.employee_bronze;

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(salary)
# MAGIC from banking_analytics.bronze_layer.employee_bronze
# MAGIC where salary == 0;

# COMMAND ----------

## 4. Calculated column: "Employee Salary Band"

df_transform = df.withColumn(
    "emp_salary_band",
    f.when(f.col("salary") < 50000, "Low Salary")
     .when(f.col("salary") < 100000, "Medium Salary")
     .when(f.col("salary") < 190000, "High Salary")

     .otherwise("Unpaid")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(role), count(*) as cnt_role
# MAGIC from banking_analytics.bronze_layer.employee_bronze
# MAGIC group by role
# MAGIC order by cnt_role desc; 

# COMMAND ----------

## 5. Calculated column: "Employee Role Group"

df_transform = df.withColumn(
    'emp_role_group',
    f.when(f.col('role') == 'Teller', 'Branch Operations')
    .when(f.col('role') == 'Customer Service', 'Customer Experience')
    .when(f.col('role') == 'Relationship Manager', 'Sales & Relationship')
    .when(f.col('role') == 'Loan Officer', 'Credit & Loans')
    .when(f.col('role') == 'Branch Manager', 'Management')
    .when(f.col('role') == 'Compliance Officer', 'Risk & Compliance')

    .otherwise("Other")
)
df_transform.display()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    "salary",
    f.col("salary").cast("float")  ## typecasting data type

).withColumn(
    'emp_hire_year',
    f.year(f.col('hire_date'))

).withColumn(
    'emp_hire_yr-mon',
    f.date_format(f.col('hire_date'), 'yyyy-MM')

).withColumn(
    'emp_tenure_yrs',
    f.floor(
        f.datediff(f.current_date(), f.col('hire_date')) / 365.25
        ).cast('int')

).withColumn(
    "emp_tenure_band",
    f.when(f.col("emp_tenure_yrs") < 3, "New Employee (0-2 Years)")
     .when(f.col("emp_tenure_yrs") < 7, "Growing Employee (3-7 Years)")
     .when(f.col("emp_tenure_yrs") < 15, "Experienced Employee (8-19 Years)")

     .otherwise("Senior Employee (20+ Years)")

).withColumn(
    "emp_salary_band",
    f.when(f.col("salary") < 50000, "Low Salary")
     .when(f.col("salary") < 100000, "Medium Salary")
     .when(f.col("salary") < 190000, "High Salary")

     .otherwise("Unpaid")

).withColumn(
    'emp_role_group',
    f.when(f.col('role') == 'Teller', 'Branch Operations')
    .when(f.col('role') == 'Customer Service', 'Customer Experience')
    .when(f.col('role') == 'Relationship Manager', 'Sales & Relationship')
    .when(f.col('role') == 'Loan Officer', 'Credit & Loans')
    .when(f.col('role') == 'Branch Manager', 'Management')
    .when(f.col('role') == 'Compliance Officer', 'Risk & Compliance')

    .otherwise("Other")
)


# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.employee_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists using SQL
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.employee_silver;

# COMMAND ----------

## Reading Table in Pyspark 
df = spark.read.table('banking_analytics.silver_layer.employee_silver')
df.display()
df.printSchema()

# COMMAND ----------

