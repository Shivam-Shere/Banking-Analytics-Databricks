# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t 
from pyspark.sql import functions as f 

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True).load('/Volumes/banking_analytics/bronze_layer/raw_data/card_transactions.csv')

df.display()  

# COMMAND ----------

display(df.limit(10))

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(df.count())
print(len(df.columns))

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('card_txn_id').isNull().cast('int')).alias('null_card_txn_id')
).display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns

]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "branches" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.card_transactions_bronze')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.card_transactions_bronze;

# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(txn_date), max(txn_date)
# MAGIC from banking_analytics.bronze_layer.card_transactions_bronze;

# COMMAND ----------

## 1. Calculated column: "txn year"

df_transform = df.withColumn(
    'txn_year',
    f.year(f.col('txn_date'))
)
df_transform.display()

# COMMAND ----------

## 2. Calculated column: "txn Year-Month"

df_transform =  df.withColumn(
    'txn_yr-mon',
    f.date_format(f.col('txn_date'), 'yyyy-MM')
)
df_transform.display()

# COMMAND ----------

## 3. Calculated column: "txn quarter"

df_transform = df.withColumn(
    "txn_quarter",
    f.concat(
        f.lit("Q"),
        f.quarter(f.col("txn_date"))
    )
)
df_transform.display()

# COMMAND ----------

## 4. Calculated column: "txn day name"

df_transform = df.withColumn(
    "txn_day_name",
    f.date_format(f.col("txn_date"), "EEEE")
)
df_transform.display()

# COMMAND ----------

## 5. Calculated column: "txn day type"

df_transform = df.withColumn(
    "txn_day_type",
    f.when(
        f.dayofweek(f.col("txn_date")).isin(1, 7),
        "Weekend"
    ).otherwise("Weekday")
)
df_transform.display()

# COMMAND ----------

## 6. Calculated column: "txn fraud status"

df_transform = df.withColumn(
    "fraud_status",
    f.when(f.col("is_fraud") == 1, "Fraudulent")
     .otherwise("Legitimate")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(amount), max(amount)
# MAGIC from banking_analytics.bronze_layer.card_transactions_bronze;

# COMMAND ----------

## 7. Calculated column: "txn amount band"

df_transform = df.withColumn(
    "amount_band",
    f.when(f.col("amount") < 1000, "Low Value")
     .when(f.col("amount") < 10000, "Medium Value")
     .when(f.col("amount") < 20000, "High Value")
     
     .otherwise("Very High Value")
)
df_transform.display()

# COMMAND ----------

## 8. Calculated column: "hivh txn amount"

df_transform = df.withColumn(
    "is_high_value_txn",
    f.when(
        f.col("amount") >= 20000,
        True
    ).otherwise(False)
)
df_transform.display()

# COMMAND ----------

## 9. Calculated column: "fraud txn amount flag"

df_transform = df.withColumn(
    "fraud_amount_flag",
    f.when(
        (f.col("is_fraud") == 1) &
        (f.col("amount") >= 20000),
        "Fraudulent High Value"
    ).otherwise("Normal")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select merchant_category, count(*) as cnt_merchant_category
# MAGIC from banking_analytics.bronze_layer.card_transactions_bronze
# MAGIC group by merchant_category
# MAGIC order by cnt_merchant_category desc;

# COMMAND ----------

## 10. Calculated column: "merchant category group"

df_transform = df.withColumn(
    "merchant_category_group",
    f.when(
        f.col("merchant_category").isin(
            "Healthcare", "Insurance"
        ),
        "Healthcare & Insurance"
    )
    .when(
        f.col("merchant_category").isin(
            "Fund Transfer", "Salary Credit"
        ),
        "Financial Services"
    )
    .when(
        f.col("merchant_category") == "ATM Withdrawal",
        "Cash & ATM"
    )
    .when(
        f.col("merchant_category").isin(
            "Travel", "Fuel"
        ),
        "Travel & Transportation"
    )
    .when(
        f.col("merchant_category").isin(
            "Utilities", "Rent"
        ),
        "Household & Utilities"
    )
    .when(
        f.col("merchant_category").isin(
            "Dining", "Groceries", "Entertainment"
        ),
        "Food & Lifestyle"
    )
    .when(
        f.col("merchant_category") == "Shopping",
        "Retail & Shopping"
    )
    .when(
        f.col("merchant_category") == "Education",
        "Education"
    )

    .otherwise("Other")
)
df_transform.display()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    'txn_year',
    f.year(f.col('txn_date'))
).withColumn(
    'txn_yr-mon',
    f.date_format(f.col('txn_date'), 'yyyy-MM')
).withColumn(
    "txn_quarter",
    f.concat(
        f.lit("Q"),
        f.quarter(f.col("txn_date"))
    )
).withColumn(
    "txn_day_name",
    f.date_format(f.col("txn_date"), "EEEE")
).withColumn(
    "txn_day_type",
    f.when(
        f.dayofweek(f.col("txn_date")).isin(1, 7),
        "Weekend"
    ).otherwise("Weekday")
).withColumn(
    "fraud_status",
    f.when(f.col("is_fraud") == 1, "Fraudulent")
     .otherwise("Legitimate")
).withColumn(
    "amount_band",
    f.when(f.col("amount") < 1000, "Low Value")
     .when(f.col("amount") < 10000, "Medium Value")
     .when(f.col("amount") < 20000, "High Value")
     
     .otherwise("Very High Value")
).withColumn(
    "is_high_value_txn",
    f.when(
        f.col("amount") >= 20000,
        True
    ).otherwise(False)
).withColumn(
    "fraud_amount_flag",
    f.when(
        (f.col("is_fraud") == 1) &
        (f.col("amount") >= 20000),
        "Fraudulent High Value"
    ).otherwise("Normal")
).withColumn(
    "merchant_category_group",
    f.when(
        f.col("merchant_category").isin(
            "Healthcare", "Insurance"
        ),
        "Healthcare & Insurance"
    )
    .when(
        f.col("merchant_category").isin(
            "Fund Transfer", "Salary Credit"
        ),
        "Financial Services"
    )
    .when(
        f.col("merchant_category") == "ATM Withdrawal",
        "Cash & ATM"
    )
    .when(
        f.col("merchant_category").isin(
            "Travel", "Fuel"
        ),
        "Travel & Transportation"
    )
    .when(
        f.col("merchant_category").isin(
            "Utilities", "Rent"
        ),
        "Household & Utilities"
    )
    .when(
        f.col("merchant_category").isin(
            "Dining", "Groceries", "Entertainment"
        ),
        "Food & Lifestyle"
    )
    .when(
        f.col("merchant_category") == "Shopping",
        "Retail & Shopping"
    )
    .when(
        f.col("merchant_category") == "Education",
        "Education"
    )

    .otherwise("Other")
)

df_transform.display()
df_transform.printSchema()


# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.card_transaction_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists using SQL
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.card_transaction_silver;