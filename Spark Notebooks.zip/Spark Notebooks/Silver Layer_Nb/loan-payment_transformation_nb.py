# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t 
from pyspark.sql import functions as f 

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True).load('/Volumes/banking_analytics/bronze_layer/raw_data/loan_payments.csv')

df.display()      

# COMMAND ----------

display(df.limit(10))

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(df.count())
print(len(df.columns))

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('payment_id').isNull().cast('int')).alias('null_payment_id')
).display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns

]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "branches" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.loan_payment_bronze')


# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.loan_payment_bronze;

# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(payment_date), max(payment_date)
# MAGIC from banking_analytics.bronze_layer.loan_payment_bronze;

# COMMAND ----------

## 1. Calculated column: "Laon Payment Year"

df_transform = df.withColumn(
    'loan_payment_year',
    f.year(f.col('payment_date'))
)
df_transform.display()

# COMMAND ----------

## 2. Calculated column: "Employee Hiring Year-Month"

df_transform =  df.withColumn(
    'loan_payment_yr-mon',
    f.date_format(f.col('payment_date'), 'yyyy-MM')
)
df_transform.display()

# COMMAND ----------

## 3. Calculated column: "Loan Payment Quarter"

df_transform = df.withColumn(
    'payment_quarter',
    f.concat(f.lit('Q'),
             f.quarter(f.col('payment_date'))
    )
)

df_transform.display()

# COMMAND ----------

## 4. Calculated column: "Loan Payment Day Name"

df_transform = df.withColumn(
    'payment_day_name',
    f.date_format(f.col('payment_date'), 'EEEE')
)
df_transform.display()

# COMMAND ----------

## 5. Calculated column: "Loan Payment Weekday v/s Weekend"

df_transform = df.withColumn(
    'payment_day_type',
    f.when(
        f.dayofweek(f.col('payment_date')).isin(1,7),
        'Weekend'
    ).otherwise('Weekday')

)
df_transform.display()

# COMMAND ----------

## 6. Calculated column: "Late Payment status"

df_transform = df.withColumn(
    'late_payment_status',
    f.when(f.col('late_payment_flag') == 1, 'Late')
     .otherwise('On Time')

)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(amount_paid), max(amount_paid)
# MAGIC from banking_analytics.bronze_layer.loan_payment_bronze;

# COMMAND ----------

## 7. Calculated column: "Loan Payment Amount band"

df_transform =  df.withColumn(
    'payment_amount_band',
    f.when(f.col('amount_paid') < 10000, 'Low')
     .when(f.col('amount_paid') < 50000, 'Medium')
     .when(f.col("amount_paid") < 80000, "High Payment")

     .otherwise("Very High Payment")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(principal_component), max(principal_component)
# MAGIC from banking_analytics.bronze_layer.loan_payment_bronze;

# COMMAND ----------

## 8. Calculated column: "Loan Principal %"

df_transform =  df.withColumn(
    'principal_percentage',
    f.when(f.col('amount_paid') > 0,
           (f.col('principal_component') / f.col('amount_paid')) * 100
    ).otherwise(0)
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(interest_component), max(interest_component)
# MAGIC from banking_analytics.bronze_layer.loan_payment_bronze;

# COMMAND ----------

## 9. Calculated column: "Loan Interest %"

df_transform = df.withColumn(
    "interest_percentage",
    f.when(
        f.col("amount_paid") > 0,
        (f.col("interest_component") / f.col("amount_paid")) * 100
    ).otherwise(0)
)
df_transform.display()

# COMMAND ----------

## 10. Calculated column: "Loan Payment Component Check"

df_transform = df.withColumn(
    "payment_component_check",
    f.when(f.abs(
                  (f.col("principal_component") + f.col("interest_component"))
                   - f.col("amount_paid")
                ) < 0.01,
                "Valid"

          ).otherwise("Mismatch")
)
df_transform.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    'loan_payment_year',
    f.year(f.col('payment_date'))

).withColumn(
    'loan_payment_yr-mon',
    f.date_format(f.col('payment_date'), 'yyyy-MM')

).withColumn(
    'payment_quarter',
    f.concat(f.lit('Q'),
             f.quarter(f.col('payment_date'))
    )

).withColumn(
    'payment_day_name',
    f.date_format(f.col('payment_date'), 'EEEE')

).withColumn(
    'payment_day_type',
    f.when(
        f.dayofweek(f.col('payment_date')).isin(1,7),
        'Weekend'
    ).otherwise('Weekday')

).withColumn(
    'late_payment_status',
    f.when(f.col('late_payment_flag') == 1, 'Late')
     .otherwise('On Time')

).withColumn(
    'payment_amount_band',
    f.when(f.col('amount_paid') < 10000, 'Low')
     .when(f.col('amount_paid') < 50000, 'Medium')
     .when(f.col("amount_paid") < 80000, "High Payment")

     .otherwise("Very High Payment")
     
).withColumn(
    'principal_percentage',
    f.when(f.col('amount_paid') > 0,
           (f.col('principal_component') / f.col('amount_paid')) * 100
    ).otherwise(0)

).withColumn(
    "interest_percentage",
    f.when(
        f.col("amount_paid") > 0,
        (f.col("interest_component") / f.col("amount_paid")) * 100
    ).otherwise(0)

).withColumn(
    "payment_component_check",
    f.when(
	f.abs((f.col("principal_component") + f.col("interest_component"))
               - f.col("amount_paid")
              ) < 0.01,
              "Valid"

    ).otherwise("Mismatch")
)
df_transform.display()
df_transform.printSchema()

# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.loan_payment_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists using SQL
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.loan_payment_silver;