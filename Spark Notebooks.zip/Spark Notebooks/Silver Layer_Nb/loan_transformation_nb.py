# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t 
from pyspark.sql import functions as f 

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True).load('/Volumes/banking_analytics/bronze_layer/raw_data/loans.csv')

df.display()      

# COMMAND ----------

display(df.limit(10))

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(df.count())
print(len(df.columns))

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('loan_id').isNull().cast('int')).alias('null_loan_id')
).display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns

]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "branches" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.loan_bronze')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.loan_bronze;

# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

## 1. Calculated column: "Loan Start Year"

df_transform = df.withColumn(
    'loan_start_year',
    f.year(f.col('start_date'))

)
df_transform.display()

# COMMAND ----------

## 2. Calculated column: "Loan Start Year-Month"

df_transform =  df.withColumn(
    'loan_start_yr-mon',
    f.date_format(f.col('start_date'), 'yyyy-MM')
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(start_date), max(start_date)
# MAGIC from banking_analytics.bronze_layer.loan_bronze; 

# COMMAND ----------

## 3. Calculated column: "Loan Age Month Difference" {Current Date - Start Date}

df_transform = df.withColumn(
    "loan_age_months",
    f.floor(
        f.months_between(f.current_date(),f.col("start_date"))
    ).cast("int")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(loan_amount), max(loan_amount)
# MAGIC from banking_analytics.bronze_layer.loan_bronze; 

# COMMAND ----------

## 4. Calculated column: "Loan Amount Band"

df_transform = df.withColumn(
    "loan_amount_band",
    f.when(f.col("loan_amount") < 500000, "Low Loan")
     .when(f.col("loan_amount") < 1500000, "Medium Loan")
     .when(f.col("loan_amount") < 3000000, "High Loan")

     .otherwise("Very High Loan")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(interest_rate), max(interest_rate)
# MAGIC from banking_analytics.bronze_layer.loan_bronze; 

# COMMAND ----------

## 5. Calculated column: "Interest Rate Band"

df_transform = df.withColumn(
    "interest_rate_band",
    f.when(f.col("interest_rate") < 7, "Low Rate")
     .when(f.col("interest_rate") < 12, "Moderate Rate")
     .when(f.col("interest_rate") < 15, "High Rate")

     .otherwise("Very High Rate")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(term_months), max(term_months)
# MAGIC from banking_analytics.bronze_layer.loan_bronze; 

# COMMAND ----------

## 6. Calculated column: "Term Band"

df_transform = df.withColumn(
    "term_band",
    f.when(f.col("term_months") <= 24, "Short Term (1-2 Years)")
     .when(f.col("term_months") <= 60, "Medium Term (3-5 Years)")
     .when(f.col("term_months") <= 120, "Long Term (6-10 Years)")
     .when(f.col("term_months") <= 180, "Extended Term (11-15 Years)")

     .otherwise("Very Long Term (16-20 Years)")
)
df_transform.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(status), count(*) as cnt_status
# MAGIC from banking_analytics.bronze_layer.loan_bronze
# MAGIC group by status
# MAGIC order by cnt_status desc; 

# COMMAND ----------

## 7. Calculated column: "Loan Status Group"

df_transform = df.withColumn(
    "loan_status_group",
    f.when(f.col("status") == "Active", "Active")
     .when(f.col("status") == "Closed", "Completed")
     .when(f.col("status") == "Defaulted", "At Risk")
     .when(f.col("status") == "Written Off", "Written Off")

     .otherwise("Other")
)
df_transform.display()     

# COMMAND ----------

# MAGIC %sql
# MAGIC select loan_type, count(*) as cnt_loan_type
# MAGIC from banking_analytics.bronze_layer.loan_bronze
# MAGIC group by loan_type
# MAGIC order by cnt_loan_type desc; 

# COMMAND ----------

## 8. Calculated column: "Estimated Monthly EMI" {Based on Interest rate and term month columns}

## Formula: EMI = Loan Amount * Interest Rate * (1 + Interest Rate)^Term Months) / ((1 + Interest Rate)^Term Months - 1)

## [EMI = P × r × (1+r)^n / ((1+r)^n - 1)]

df_transform = df.withColumn(
    "estimated_monthly_emi",
    (
        f.col("loan_amount") * (f.col("interest_rate") / 12 / 100) *
        f.pow(
            1 + (f.col("interest_rate") / 12 / 100), f.col("term_months"))
    ) /

    (
        f.pow(
            1 + (f.col("interest_rate") / 12 / 100), f.col("term_months")) - 1
    )
)
df_transform.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    'loan_start_year',
    f.year(f.col('start_date'))

).withColumn(
    'loan_start_yr-mon',
    f.date_format(f.col('start_date'), 'yyyy-MM')
).withColumn(
    "loan_age_months",
    f.floor(
        f.months_between(f.current_date(),f.col("start_date"))
    ).cast("int")

).withColumn(
    "loan_age_band",  ## Calculated on "loan_age_months"
    f.when(f.col("loan_age_months") < 12, "0-11 Months")
     .when(f.col("loan_age_months") < 36, "1-2 Years")
     .when(f.col("loan_age_months") < 60, "3-4 Years")
     
     .otherwise("5+ Years")

).withColumn(
    "loan_amount_band",
    f.when(f.col("loan_amount") < 500000, "Low Loan")
     .when(f.col("loan_amount") < 1500000, "Medium Loan")
     .when(f.col("loan_amount") < 3000000, "High Loan")

     .otherwise("Very High Loan")

).withColumn(
    "interest_rate_band",
    f.when(f.col("interest_rate") < 7, "Low Rate")
     .when(f.col("interest_rate") < 12, "Moderate Rate")
     .when(f.col("interest_rate") < 15, "High Rate")

     .otherwise("Very High Rate")

).withColumn(
    "term_band",
    f.when(f.col("term_months") <= 24, "Short Term (1-2 Years)")
     .when(f.col("term_months") <= 60, "Medium Term (3-5 Years)")
     .when(f.col("term_months") <= 120, "Long Term (6-10 Years)")
     .when(f.col("term_months") <= 180, "Extended Term (11-15 Years)")

     .otherwise("Very Long Term (16-20 Years)")

).withColumn(
    "loan_status_group",
    f.when(f.col("status") == "Active", "Active")
     .when(f.col("status") == "Closed", "Completed")
     .when(f.col("status") == "Defaulted", "At Risk")
     .when(f.col("status") == "Written Off", "Written Off")

     .otherwise("Other")

).withColumn(
    "estimated_monthly_emi",
    (
        f.col("loan_amount") * (f.col("interest_rate") / 12 / 100) *
        f.pow(
            1 + (f.col("interest_rate") / 12 / 100), f.col("term_months"))
    ) /

    (
        f.pow(
            1 + (f.col("interest_rate") / 12 / 100), f.col("term_months")) - 1
    )
)


# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.loan_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists using SQL
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.loan_silver;

# COMMAND ----------

## Read Table using Spark
df = spark.read.table('banking_analytics.silver_layer.loan_silver')
df.display()
df.printSchema()