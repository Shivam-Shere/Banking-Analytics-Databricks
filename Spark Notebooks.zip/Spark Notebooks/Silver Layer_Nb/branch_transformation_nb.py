# Databricks notebook source
# MAGIC %md
# MAGIC ## **1. Import Libraries**

# COMMAND ----------

from pyspark.sql import types as t
from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## **2. Load raw data**

# COMMAND ----------

df = spark.read.format('csv').option('inferSchema', True) \
    .option('header', True).load('/Volumes/banking_analytics/bronze_layer/raw_data/branches.csv')

df.display()    

# COMMAND ----------

display(df.limit(10))  

# COMMAND ----------

## Check columns datatypes
df.printSchema()

# COMMAND ----------

## Values count check
print(df.count())
print(len(df.columns))

# COMMAND ----------

## Descriptive Statistics: (Spark can not calculate numerical statistics for string columns)
df.describe().display()

# COMMAND ----------

## Check missing value for single column only
df.select(
    f.sum(f.col('branch_id').isNull().cast('int')).alias('null_branch_id')
).display()

# COMMAND ----------

## Check Missing Values for all columns: use loop with list
df.select([
    f.sum(f.col(a_null).isNull().cast('int')).alias(a_null)
    for a_null in df.columns
]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **3. Raw Data Store into Bronze Delta Table**

# COMMAND ----------

# save "branches" data to Delta Tables:
df.write.format('delta') \
    .mode('overwrite') \
    .saveAsTable('banking_analytics.bronze_layer.branch_bronze')


# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table
# MAGIC select * 
# MAGIC from banking_analytics.bronze_layer.branch_bronze;

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## **4. Data Transformation**

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct city, state
# MAGIC from banking_analytics.bronze_layer.branch_bronze;

# COMMAND ----------

## 1. Calculated column: "Full Location"

df_transform = df.withColumn(
    'branch_location',
    f.concat_ws(
        ', ',
        f.col('city'),
        f.col('state')
    )
).display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(state)
# MAGIC from banking_analytics.bronze_layer.branch_bronze;

# COMMAND ----------

## 2. Calculated column: "Region"

df_transform =  df.withColumn(
    'branch_region',

    f.when(f.col('state').isin('Maharashtra', 'Gujarat'), 'West')
    .when(f.col('state').isin('West Bengal'), 'East')
    .when(f.col('state').isin('Punjab', 'Uttar Pradesh', 'Rajasthan', 'Delhi'), 'North')
    .when(f.col('state').isin('Madhya Pradesh', 'Karnataka', 'Kerala', 'Tamil Nadu', 'Telangana' ), 'South')

    .otherwise('Other')

).display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(opened_date) as min_date,
# MAGIC max(opened_date) as max_date
# MAGIC from banking_analytics.bronze_layer.branch_bronze;

# COMMAND ----------

## 3. Calculated column: "Branch Open Year"

df_transform = df.withColumn(
    'branch_open_year',
    f.year(f.col('opened_date'))
).display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(opened_date)
# MAGIC from banking_analytics.bronze_layer.branch_bronze;

# COMMAND ----------

## 4. Calculated column: "Branch Age Years"

df_transform = df.withColumn(
    'branch_age_years',
    f.floor(
        f.datediff(f.current_date(), f.col('opened_date')) / 365.25
    ).cast('int')

).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **5. Save transformed data into Silver Table**

# COMMAND ----------

# Merge all transformations together

df_transform = df.withColumn(
    'branch_location',
    f.concat_ws(
        ', ',
        f.col('city'),
        f.col('state')
    )
).withColumn(
    'branch_region',

    f.when(f.col('state').isin('Maharashtra', 'Gujarat'), 'West')
    .when(f.col('state').isin('West Bengal'), 'East')
    .when(f.col('state').isin('Punjab', 'Uttar Pradesh', 'Rajasthan', 'Delhi'), 'North')
    .when(f.col('state').isin('Madhya Pradesh', 'Karnataka', 'Kerala', 'Tamil Nadu', 'Telangana' ), 'South')

    .otherwise('Other')

).withColumn(
    'branch_open_year',
    f.year(f.col('opened_date'))
).withColumn(
    'branch_age_years',
    f.floor(
        f.datediff(f.current_date(), f.col('opened_date')) / 365.25
    ).cast('int')

).withColumn(
    'branch_age_band',  ## 5. Calculated column: "Branch Age Band"
    f.when(f.col('branch_age_years') < 3, 'New Branch (0-2 Years)')
    .when(f.col('branch_age_years') < 7, 'Growing Branch (3-6 Years)')
    .when(f.col('branch_age_years') < 15, 'Established Branch (7-14 Years)')
    .when(f.col('branch_age_years') < 25, 'Mature Branch (15-24 Years)')

    .otherwise('Legacy Branch (25+ Years)')

)

# Save to silver table
df_transform.write.format('delta').mode('overwrite') \
    .saveAsTable('banking_analytics.silver_layer.branch_silver')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the table exists
# MAGIC select *
# MAGIC from banking_analytics.silver_layer.branch_silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC select max(branch_age_years)
# MAGIC from banking_analytics.silver_layer.branch_silver;